<?php
require_once __DIR__.'/vendor/autoload.php';

use Illuminate\Database\Capsule\Manager as Capsule;
use \Silex\Application as Silex;
use \Symfony\Component\HttpFoundation\Request as Request;
use \Symfony\Component\HttpFoundation\Response as Response;

$app = new Silex();
$app['debug'] = true;

//Lien avec la base de donnée
$app->register(
    new \JG\Silex\Provider\CapsuleServiceProvider(),
    [
        'capsule.connections' => [
            'default' => [
                'driver'    => 'mysql',
                'host'      => 'localhost',
                'database'  => 'soireejeux',
                'username'  => 'root',
                'password'  => 'root',
            ]
        ]
    ]
);

header('Content-Type: json');

//Récupérer tout les users
$app->get('/users', function() use($app) {
    $users = Capsule::table('users')->get();
    return new Response(json_encode($users), 200);
});

//Récupérer toute les inscriptions
$app->get('/inscrits', function() use($app) {
    $users = Capsule::table('inscriptions')->get();
    return new Response(json_encode($users), 200);
});

//Récupérer un user
$app->get('/users/{id}', function($id) use($app) {
    $user = Capsule::table('users')
        ->where('id', $id)->get();
    return new Response(json_encode($user), 200);
});

//Récupérer un inscrit
$app->get('/inscrit/{id}', function($id) use($app) {
    $user = Capsule::table('inscriptions')
        ->where('id', $id)->get();
    return new Response(json_encode($user), 200);
});

//Ajouter un inscrit
$app->post('/inscrit/add', function (Request $request) use ($app){
    $data = ['civilite' => $request->get('civilite'),
        'nom' => $request->get('nom'),
        'prenom' => $request->get('prenom'),
        'adresse' => $request->get('adresse'),
        'cp' => $request->get('cp'),
        'ville' => $request->get('ville'),
        'dateNaissance' => $request->get('dateNaissance'),
        'email' => $request->get('email'),
        'membre' => $request->get('membre'),
        'jeux' => $request->get('jeux'),
        'valide' => $request->get('valide')];

    $inscrit = Capsule::table('inscriptions')->insert($data);

    return new Response("inscrit crée", 201);
});

//Supprimer un inscrit
$app->delete('/inscrit/{id}/delete', function ($id) use ($app){

    $user = Capsule::table('inscriptions')->where('id', $id)->get();

    if($user){
        $user = Capsule::table('inscriptions')
            ->where('id', $id)->delete();
        return new Response("inscrit supprimé avec succes", 200);
    }
    else{
        return new Response("404 : pas d'inscrit avec l'id".$id, 404);
    }
});

//Modifier un inscrit
$app->post('/inscrit/{id}/update', function (Request $request, $id) use ($app){
    $data = json_decode($request->getContent());

    $data = [
        'civilite' => $request->get('civilite'),
        'nom' => $request->get('nom'),
        'prenom' => $request->get('prenom'),
        'adresse' => $request->get('adresse'),
        'cp' => $request->get('cp'),
        'ville' => $request->get('ville'),
        'dateNaissance' => $request->get('dateNaissance'),
        'email' => $request->get('email'),
        'membre' => $request->get('membre'),
        'jeux' => $request->get('jeux'),
        'valide' => $request->get('valide')
    ];

    $user = Capsule::table('inscriptions')->where('id', $id)->get();

    if($user){
        $inscrit = Capsule::table('inscriptions')->where('id', $id)->update($data);
        return new Response(json_encode($inscrit), 200);
    }
    else{
        return new Response("404 : pas d'inscrit avec l'id".$id, 404);
    }
});

$app->post('/inscrit/{id}/validate', function(Request $request, $id) use ($app){
    $data = [
        'valide' => 2
    ];
    $user = Capsule::table('inscriptions')->where('id', $id)->where('valide', 1)->get();
    if($user) {
        $inscrit = Capsule::table('inscriptions')->where('id', $id)->update($data);
        return new Response(json_encode($inscrit), 200);
    }
    else{
        return new Response("403 : requête non autorisée,l'inscrit".$id." n'est pas à valider", 403);
    }
});

$app->post('/inscrit/{id}/refuse', function(Request $request, $id) use ($app){
    $data = [
        'valide' => 0
    ];
    $user = Capsule::table('inscriptions')->where('id', $id)->where('valide', 1)->get();
    if($user) {
        $inscrit = Capsule::table('inscriptions')->where('id', $id)->update($data);
        return new Response(json_encode($inscrit), 200);
    }
    else{
        return new Response("403 : requête non autorisée, l'inscrit".$id." n'est pas à refuser", 403);
    }
});

$app->get('/inscrits/toValid', function() use ($app){
    $user = Capsule::table('inscriptions')
        ->where('valide', 1)->get();
    if($user){
        return new Response(json_encode($user), 200);
    }
    else{
        return new Response("404 : pas d'inscrits à valider", 404);
    }

});

$app->run();